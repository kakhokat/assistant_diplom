from __future__ import annotations

import random
import re
from collections import Counter
from dataclasses import dataclass
from dataclasses import field
from typing import Any
from typing import Iterable
from uuid import uuid4

import httpx
from fastapi import HTTPException
from fastapi import status

from clients.auth_client import AuthClient
from clients.catalog_client import CatalogClient
from clients.llm_client import LocalLlmClient
from clients.ugc_client import UgcClient
from core.capabilities import get_capabilities
from core.capabilities import get_supported_intents
from core.settings import settings
from core.text_tools import normalize_for_match
from core.text_tools import pick_best_candidate
from domain.models import AssistantFeedbackRequest
from domain.models import AssistantFeedbackResponse
from domain.models import AssistantResponse
from services.session_store import FeedbackStore
from services.session_store import LlmCircuitStore
from services.session_store import NullFeedbackStore
from services.session_store import NullJsonCacheStore
from services.session_store import NullLlmCircuitStore
from services.session_store import ParseCacheStore
from services.session_store import PublicResponseCacheStore
from services.session_store import RedisFeedbackStore
from services.session_store import RedisLlmCircuitStore
from services.session_store import RedisParseCacheStore
from services.session_store import RedisPublicResponseCacheStore
from services.session_store import RedisSessionStore
from services.session_store import SessionStore


@dataclass(slots=True)
class QueryPlan:
    intent: str
    confidence: float
    source: str
    film_title: str | None = None
    person_name: str | None = None
    search_queries: list[str] = field(default_factory=list)
    requires_auth: bool | None = None
    reason: str | None = None


class AssistantService:
    def __init__(
        self,
        auth_client: AuthClient,
        catalog_client: CatalogClient,
        ugc_client: UgcClient,
        session_store: SessionStore,
        llm_client: LocalLlmClient | None = None,
        parse_cache: ParseCacheStore | None = None,
        public_response_cache: PublicResponseCacheStore | None = None,
        feedback_store: FeedbackStore | None = None,
        llm_circuit_store: LlmCircuitStore | None = None,
    ):
        self.auth_client = auth_client
        self.catalog_client = catalog_client
        self.ugc_client = ugc_client
        self.session_store = session_store
        self.llm_client = llm_client
        self.parse_cache = parse_cache or NullJsonCacheStore()
        self.public_response_cache = public_response_cache or NullJsonCacheStore()
        self.feedback_store = feedback_store or NullFeedbackStore()
        self.llm_circuit_store = llm_circuit_store or NullLlmCircuitStore()

    async def _prepare_film_cards(
        self,
        items: list[dict[str, Any]],
        authorization: str | None,
    ) -> list[dict[str, Any]]:
        details_by_id: dict[str, dict[str, Any]] = {}
        if items:
            details = await self._load_film_details(
                [str(item.get('uuid')) for item in items if item.get('uuid')],
                authorization,
            )
            details_by_id = {str(item.get('uuid')): item for item in details if item.get('uuid')}

        prepared: list[dict[str, Any]] = []
        for item in items:
            film_id = str(item.get('uuid') or '')
            detail = details_by_id.get(film_id, {})
            genres = await self._resolve_genre_names(detail.get('genre') or [], authorization) if detail else []
            prepared.append(
                {
                    'uuid': item.get('uuid'),
                    'title': item.get('title'),
                    'original_title': item.get('original_title') or detail.get('original_title'),
                    'imdb_rating': item.get('imdb_rating'),
                    'genre': genres,
                    'directors': detail.get('directors') or [],
                    'description': detail.get('description'),
                }
            )
        return prepared

    async def public_feed(self, limit: int, authorization: str | None) -> list[dict[str, Any]]:
        items = await self._catalog_list_top_films(authorization, limit=limit)
        return await self._prepare_film_cards(items, authorization)

    async def public_search(self, query: str, authorization: str | None) -> list[dict[str, Any]]:
        items = await self._catalog_search_films(query.strip(), authorization)
        return await self._prepare_film_cards(items, authorization)

    async def submit_feedback(self, payload: AssistantFeedbackRequest) -> AssistantFeedbackResponse:
        await self.feedback_store.record(
            {
                'session_id': payload.session_id,
                'query': payload.query,
                'normalized_query': normalize_for_match(payload.query),
                'reaction': payload.reaction,
                'intent': payload.intent or 'unknown',
                'metadata': payload.metadata,
            }
        )
        return AssistantFeedbackResponse(status='ok')

    async def handle_query(
        self,
        query: str,
        authorization: str | None,
        session_id: str | None = None,
    ) -> AssistantResponse:
        current_session_id = session_id or uuid4().hex
        session = await self.session_store.load(current_session_id)
        parse_cache_key = self._build_parse_cache_key(query, session)

        try:
            plan = await self._build_plan(query, session, parse_cache_key)

            if plan.intent == 'bookmarks':
                if not self._has_bearer(authorization):
                    response = self._auth_required_response(query, current_session_id, session, 'bookmarks')
                else:
                    response = await self._handle_bookmarks(query, authorization, current_session_id, session)
            elif plan.intent == 'recommend_by_genre':
                if not self._has_bearer(authorization):
                    response = self._auth_required_response(query, current_session_id, session, 'recommend_by_genre')
                else:
                    response = await self._handle_recommend_by_genre(query, authorization, current_session_id, session)
            elif plan.intent == 'recommend_general':
                response = await self._handle_recommend_general(query, authorization, current_session_id, session)
            elif plan.intent == 'recommend_by_person':
                response = await self._handle_recommend_by_person(
                    query,
                    authorization,
                    current_session_id,
                    session,
                    person_name=plan.person_name,
                    search_queries=plan.search_queries,
                )
            elif plan.intent == 'person_movie_count':
                response = await self._handle_person_movie_count(
                    query,
                    authorization,
                    current_session_id,
                    session,
                    person_name=plan.person_name,
                    search_queries=plan.search_queries,
                )
            elif plan.intent == 'person_filmography':
                response = await self._handle_person_filmography(
                    query,
                    authorization,
                    current_session_id,
                    session,
                    person_name=plan.person_name,
                    search_queries=plan.search_queries,
                )
            elif plan.intent in {'film_rating', 'film_director', 'film_duration', 'film_genres', 'film_overview'}:
                response = await self._handle_film_query(
                    plan.intent,
                    query,
                    authorization,
                    current_session_id,
                    session,
                    film_title=plan.film_title,
                    search_queries=plan.search_queries,
                )
            else:
                response = self._response(
                    query=query,
                    session_id=current_session_id,
                    intent='help',
                    answer_text=self._help_text(),
                    confidence=max(plan.confidence, 0.35),
                    used_services=[] if plan.source == 'deterministic' else ['llm'],
                    metadata={'reason': plan.reason},
                    context=session,
                )

            response.metadata['plan_source'] = plan.source
            response.metadata['parse_cache_key'] = parse_cache_key
            response.metadata['llm_fallback_used'] = plan.source in {'llm', 'parse_cache'}

            await self._maybe_store_public_response(response, authorization)
            await self.session_store.save(current_session_id, session)
            return response
        except httpx.HTTPStatusError as exc:
            status_code = exc.response.status_code if exc.response is not None else 502
            detail = exc.response.text if exc.response is not None else str(exc)
            raise HTTPException(status_code=status_code, detail=f'upstream error: {detail}') from exc
        except httpx.HTTPError as exc:
            raise HTTPException(status_code=502, detail=f'upstream connection error: {exc}') from exc

    async def _build_plan(self, query: str, session: dict[str, Any], parse_cache_key: str) -> QueryPlan:
        deterministic = self._deterministic_plan(query, session)
        if self._should_accept_deterministic_plan(deterministic):
            return deterministic

        cached_plan = await self.parse_cache.load(parse_cache_key)
        if cached_plan:
            return QueryPlan(
                intent=str(cached_plan.get('intent') or 'help'),
                confidence=float(cached_plan.get('confidence') or 0.5),
                source='parse_cache',
                film_title=cached_plan.get('film_title'),
                person_name=cached_plan.get('person_name'),
                search_queries=list(cached_plan.get('search_queries') or []),
                requires_auth=cached_plan.get('requires_auth'),
                reason=cached_plan.get('reason'),
            )

        if self.llm_client and self.llm_client.is_enabled():
            if await self.llm_circuit_store.is_open():
                deterministic.source = 'llm_circuit_open'
                deterministic.reason = 'llm circuit is open'
                return deterministic
            llm_plan = await self._llm_plan(query, session)
            if llm_plan is not None:
                await self.parse_cache.save(
                    parse_cache_key,
                    {
                        'intent': llm_plan.intent,
                        'confidence': llm_plan.confidence,
                        'film_title': llm_plan.film_title,
                        'person_name': llm_plan.person_name,
                        'search_queries': llm_plan.search_queries,
                        'requires_auth': llm_plan.requires_auth,
                        'reason': llm_plan.reason,
                    },
                )
                return llm_plan
        return deterministic

    def _deterministic_plan(self, query: str, session: dict[str, Any]) -> QueryPlan:
        intent = self._detect_intent(query)
        plan = QueryPlan(intent=intent, confidence=0.72, source='deterministic')

        if intent in {'film_rating', 'film_director', 'film_duration', 'film_genres', 'film_overview'}:
            plan.film_title = self._extract_film_title_with_context(query, session)
            if plan.film_title:
                plan.search_queries = [plan.film_title]
            else:
                plan.confidence = 0.25
        elif intent in {'person_movie_count', 'person_filmography', 'recommend_by_person'}:
            plan.person_name = self._extract_person_name_with_context(query, session)
            if plan.person_name:
                plan.search_queries = [plan.person_name]
            else:
                plan.confidence = 0.25
        elif intent == 'recommend_general':
            plan.confidence = 0.85
        elif intent == 'bookmarks':
            plan.requires_auth = True
            plan.confidence = 0.95
        elif intent == 'recommend_by_genre':
            plan.requires_auth = True
            plan.confidence = 0.9
        elif intent == 'help':
            plan.confidence = 0.2
        return plan

    async def _llm_plan(self, query: str, session: dict[str, Any]) -> QueryPlan | None:
        if not self.llm_client or not self.llm_client.is_enabled():
            return None
        parsed = await self.llm_client.parse_query(query, session)
        if parsed is None:
            await self.llm_circuit_store.record_failure()
            return None
        if parsed.intent not in get_supported_intents():
            await self.llm_circuit_store.record_failure()
            return None
        await self.llm_circuit_store.record_success()
        return QueryPlan(
            intent=parsed.intent,
            confidence=parsed.confidence,
            source='llm',
            film_title=parsed.film_title,
            person_name=parsed.person_name,
            search_queries=[item for item in parsed.search_queries if item],
            requires_auth=parsed.requires_auth,
            reason=parsed.reason,
        )

    @staticmethod
    def _should_accept_deterministic_plan(plan: QueryPlan) -> bool:
        if plan.intent in {'bookmarks', 'recommend_by_genre', 'recommend_general'}:
            return True
        if plan.intent in {'film_rating', 'film_director', 'film_duration', 'film_genres', 'film_overview'}:
            return bool(plan.film_title)
        if plan.intent in {'person_movie_count', 'person_filmography', 'recommend_by_person'}:
            return bool(plan.person_name)
        return plan.intent != 'help'

    def _has_bearer(self, authorization: str | None) -> bool:
        return bool(authorization and authorization.strip())

    async def _catalog_authorization(self, authorization: str | None) -> tuple[str, bool]:
        if self._has_bearer(authorization):
            return str(authorization), False
        return await self.auth_client.service_authorization(), True

    async def _catalog_call(self, method_name: str, *args: Any, authorization: str | None, **kwargs: Any) -> Any:
        method = getattr(self.catalog_client, method_name)
        auth_header, _ = await self._catalog_authorization(authorization)
        try:
            return await method(*args, auth_header, **kwargs)
        except httpx.HTTPStatusError as exc:
            if exc.response is not None and exc.response.status_code == 401:
                refreshed_auth = await self.auth_client.service_authorization(force_refresh=True)
                return await method(*args, refreshed_auth, **kwargs)
            raise

    async def _catalog_search_films(self, query: str, authorization: str | None) -> list[dict[str, Any]]:
        return await self._catalog_call('search_films', query, authorization=authorization)

    async def _catalog_search_genres(self, query: str, authorization: str | None) -> list[dict[str, Any]]:
        return await self._catalog_call('search_genres', query, authorization=authorization)

    async def _catalog_list_top_films(self, authorization: str | None, limit: int = 10) -> list[dict[str, Any]]:
        return await self._catalog_call('list_top_films', authorization=authorization, limit=limit)

    async def _catalog_film_details(self, film_id: str, authorization: str | None) -> dict[str, Any]:
        return await self._catalog_call('film_details', film_id, authorization=authorization)

    async def _catalog_genre_details(self, genre_id: str, authorization: str | None) -> dict[str, Any]:
        return await self._catalog_call('genre_details', genre_id, authorization=authorization)

    async def _catalog_films_by_genre(self, genre_id: str, authorization: str | None) -> list[dict[str, Any]]:
        return await self._catalog_call('films_by_genre', genre_id, authorization=authorization)

    async def _catalog_search_persons(self, query: str, authorization: str | None) -> list[dict[str, Any]]:
        return await self._catalog_call('search_persons', query, authorization=authorization)

    async def _catalog_person_details(self, person_id: str, authorization: str | None) -> dict[str, Any]:
        return await self._catalog_call('person_details', person_id, authorization=authorization)

    async def _me_or_none(self, authorization: str | None) -> dict[str, Any] | None:
        try:
            return await self.auth_client.me(authorization)
        except HTTPException as exc:
            if exc.status_code == status.HTTP_401_UNAUTHORIZED:
                return None
            raise

    def _build_parse_cache_key(self, query: str, session: dict[str, Any]) -> str:
        parts = [settings.ASSISTANT_PARSE_CACHE_VERSION, normalize_for_match(query)]
        if self._looks_like_film_followup(query) and session.get('film_title'):
            parts.append(f"film={normalize_for_match(str(session['film_title']))}")
        if self._looks_like_person_followup(query) and session.get('person_name'):
            parts.append(f"person={normalize_for_match(str(session['person_name']))}")
        return '|'.join(item for item in parts if item)

    def _public_response_cache_key(self, intent: str, *, entity_type: str, entity_id: str) -> str:
        return f'{intent}|{entity_type}|{entity_id}'

    async def _load_cached_public_response(
        self,
        cache_key: str,
        query: str,
        session_id: str,
        session: dict[str, Any],
    ) -> AssistantResponse | None:
        cached_payload = await self.public_response_cache.load(cache_key)
        if not cached_payload:
            return None
        cached_response = AssistantResponse.model_validate(cached_payload)
        self._remember(session, cached_response.context)
        metadata = dict(cached_response.metadata)
        metadata['response_cache_hit'] = True
        return AssistantResponse(
            query=query,
            session_id=session_id,
            intent=cached_response.intent,
            answer=cached_response.answer,
            answer_text=cached_response.answer_text,
            speak_text=cached_response.speak_text,
            requires_auth=cached_response.requires_auth,
            confidence=cached_response.confidence,
            used_services=list(cached_response.used_services),
            metadata=metadata,
            context=dict(session),
            result=cached_response.result,
            alternatives=list(cached_response.alternatives),
        )

    async def _maybe_store_public_response(self, response: AssistantResponse, authorization: str | None) -> None:
        if self._has_bearer(authorization):
            return
        cache_key = str(response.metadata.get('public_response_cache_key') or '')
        if not cache_key:
            return
        await self.public_response_cache.save(cache_key, response.model_dump())

    def _auth_required_response(
        self,
        query: str,
        session_id: str,
        context: dict[str, Any],
        intent: str,
    ) -> AssistantResponse:
        return self._response(
            query=query,
            session_id=session_id,
            intent=intent,
            answer_text='Для этого запроса нужно войти в систему. После входа я смогу показать персональные данные.',
            confidence=0.95,
            used_services=[],
            metadata={},
            context=dict(context),
            requires_auth=True,
        )

    def _detect_intent(self, query: str) -> str:
        text = self._normalize(query)
        if any(token in text for token in ['заклад', 'избранн']):
            return 'bookmarks'
        if any(token in text for token in ['посовет', 'рекоменд']) and any(
            token in text for token in ['актёр', 'актер', 'режисс', 'автор']
        ):
            return 'recommend_by_person'
        if any(token in text for token in ['посовет', 'рекоменд']) and any(
            token in text for token in ['любим', 'предпочтен']
        ):
            return 'recommend_by_genre'
        if any(
            token in text
            for token in ['посовет', 'рекоменд', 'что посмотреть']
        ):
            return 'recommend_general'
        if any(
            token in text
            for token in ['сколько фильмов']
        ):
            return 'person_movie_count'
        if any(
            token in text
            for token in [
                'фильмография',
                'какие фильмы у',
                'фильмы с акт',
                'фильмы с режисс',
                'фильмы у ',
            ]
        ):
            return 'person_filmography'
        if any(
            token in text
            for token in ['сколько длится', 'длительность', 'идет фильм', 'идёт фильм']
        ):
            return 'film_duration'
        if any(
            token in text
            for token in [
                'кто режисс',
                'кто снял',
                'кто снимал',
                'кто поставил',
                'режиссер фильма',
                'режиссёр фильма',
                'автор фильма',
            ]
        ):
            return 'film_director'
        if any(token in text for token in ['оценк', 'рейтинг']):
            return 'film_rating'
        if any(token in text for token in ['жанр']):
            return 'film_genres'
        if any(
            token in text
            for token in [
                'о чем фильм',
                'о чём фильм',
                'расскажи про фильм',
                'что за фильм',
                'информация о фильме',
                'сводк',
                'описан',
                'сюжет',
                'кратко о фильме',
            ]
        ):
            return 'film_overview'
        return 'help'

    async def _format_person_name_for_answer(self, name: str, authorization: str | None) -> str:
        try:
            candidates = await self._catalog_search_persons(name, authorization)
        except Exception:
            return name
        if not candidates:
            return name
        normalized = normalize_for_match(name)
        exact = next(
            (
                item for item in candidates
                if normalize_for_match(item.get('full_name', '')) == normalized
                or normalized in [normalize_for_match(alias) for alias in (item.get('aliases') or [])]
            ),
            candidates[0],
        )
        full_name = exact.get('full_name') or name
        return full_name

    async def _format_person_names_for_answer(self, names: list[str], authorization: str | None) -> list[str]:
        return [await self._format_person_name_for_answer(name, authorization) for name in names]

    @staticmethod
    def _display_title(item: dict[str, Any]) -> str:
        title = str(item.get('title') or '').strip()
        original_title = str(item.get('original_title') or '').strip()
        if title and original_title and normalize_for_match(title) != normalize_for_match(original_title):
            return f'{title} ({original_title})'
        return title or original_title

    @staticmethod
    def _genre_display_name(genre_info: dict[str, Any], fallback: str) -> str:
        return str(genre_info.get('name') or fallback).strip() or fallback

    async def _handle_film_query(
        self,
        intent: str,
        query: str,
        authorization: str | None,
        session_id: str,
        session: dict[str, Any],
        film_title: str | None = None,
        search_queries: list[str] | None = None,
    ) -> AssistantResponse:
        title = film_title or self._extract_film_title_with_context(query, session)
        if not title:
            return self._response(
                query=query,
                session_id=session_id,
                intent=intent,
                answer_text='Не удалось понять название фильма. Лучше написать его в кавычках или сначала выбрать фильм поиском.',
                confidence=0.2,
                used_services=[],
                metadata={},
                context=session,
            )

        film, alternatives, used_query = await self._resolve_film(title, search_queries or [], authorization)
        if not film:
            return self._response(
                query=query,
                session_id=session_id,
                intent=intent,
                answer_text=f'Не нашёл фильм по запросу: {title}.',
                confidence=0.2,
                used_services=['catalog'],
                metadata={'film_query': title, 'search_queries': self._candidate_queries(title, search_queries or [])},
                context=session,
                alternatives=alternatives,
            )

        cache_key = self._public_response_cache_key(intent, entity_type='film', entity_id=str(film['uuid']))
        if not self._has_bearer(authorization):
            cached = await self._load_cached_public_response(cache_key, query, session_id, session)
            if cached is not None:
                return cached

        detail = await self._catalog_film_details(film['uuid'], authorization)
        genre_names = await self._resolve_genre_names(detail.get('genre') or [], authorization)
        matched_title = self._display_title(detail or film) or detail.get('title', film.get('title', title))

        result = {
            'type': 'film',
            'id': detail.get('uuid', film.get('uuid')),
            'title': matched_title,
            'rating': detail.get('imdb_rating'),
            'duration': detail.get('runtime_minutes'),
            'genres': genre_names,
            'director': ', '.join(detail.get('directors') or []),
            'description': detail.get('description'),
        }
        context = {
            'film_id': result['id'],
            'film_title': matched_title,
            'person_name': result['director'],
        }
        self._remember(session, context)

        if intent == 'film_rating':
            rating = detail.get('imdb_rating')
            answer = f'Рейтинг фильма «{matched_title}» — {rating}.' if rating is not None else f'У фильма «{matched_title}» пока нет рейтинга IMDb.'
        elif intent == 'film_director':
            directors = detail.get('directors') or []
            formatted_directors = await self._format_person_names_for_answer(directors, authorization) if directors else []
            result['director'] = ', '.join(formatted_directors)
            context['person_name'] = result['director']
            answer = (
                f'Режиссёр фильма «{matched_title}» — {", ".join(formatted_directors)}.'
                if formatted_directors
                else f'У меня нет данных о режиссёре фильма «{matched_title}».'
            )
        elif intent == 'film_duration':
            runtime = detail.get('runtime_minutes')
            answer = f'Фильм «{matched_title}» длится {runtime} минут.' if runtime else f'У меня нет данных о длительности фильма «{matched_title}».'
        elif intent == 'film_genres':
            answer = f'У фильма «{matched_title}» жанры: {", ".join(genre_names)}.' if genre_names else f'У меня нет данных о жанрах фильма «{matched_title}».'
        else:
            description = str(detail.get('description') or '').strip()
            extra_parts: list[str] = []
            if detail.get('imdb_rating') is not None:
                extra_parts.append(f'рейтинг IMDb {detail["imdb_rating"]}')
            if detail.get('runtime_minutes'):
                extra_parts.append(f'длительность {detail["runtime_minutes"]} минут')
            if genre_names:
                extra_parts.append(f'жанры: {", ".join(genre_names)}')
            extra = f" Также: {'; '.join(extra_parts)}." if extra_parts else ''
            if description:
                answer = f'Краткая сводка по фильму «{matched_title}»: {description}.{extra}'
            else:
                parts = [f'«{matched_title}»']
                if detail.get('imdb_rating') is not None:
                    parts.append(f'рейтинг IMDb {detail["imdb_rating"]}')
                if detail.get('runtime_minutes'):
                    parts.append(f'длительность {detail["runtime_minutes"]} минут')
                if genre_names:
                    parts.append(f'жанры: {", ".join(genre_names)}')
                answer = 'Фильм ' + ', '.join(parts) + '.'

        return self._response(
            query=query,
            session_id=session_id,
            intent=intent,
            answer_text=answer,
            confidence=0.92,
            used_services=['catalog'],
            metadata={'film_id': result['id'], 'matched_title': matched_title, 'search_query': used_query, 'public_response_cache_key': cache_key},
            context=session,
            result=result,
            alternatives=alternatives,
        )

    async def _handle_person_movie_count(
        self,
        query: str,
        authorization: str | None,
        session_id: str,
        session: dict[str, Any],
        person_name: str | None = None,
        search_queries: list[str] | None = None,
    ) -> AssistantResponse:
        raw_name = person_name or self._extract_person_name_with_context(query, session)
        if not raw_name:
            return self._response(
                query=query,
                session_id=session_id,
                intent='person_movie_count',
                answer_text='Не удалось понять имя автора. Лучше написать его в кавычках.',
                confidence=0.2,
                used_services=[],
                metadata={},
                context=session,
            )
        person, alternatives, used_query = await self._resolve_person(raw_name, search_queries or [], authorization)
        if not person:
            return self._response(
                query=query,
                session_id=session_id,
                intent='person_movie_count',
                answer_text=f'Не нашёл человека по запросу: {raw_name}.',
                confidence=0.2,
                used_services=['catalog'],
                metadata={'person_query': raw_name, 'search_queries': self._candidate_queries(raw_name, search_queries or [])},
                context=session,
                alternatives=alternatives,
            )
        cache_key = self._public_response_cache_key('person_movie_count', entity_type='person', entity_id=str(person['uuid']))
        if not self._has_bearer(authorization):
            cached = await self._load_cached_public_response(cache_key, query, session_id, session)
            if cached is not None:
                return cached

        detail = await self._catalog_person_details(person['uuid'], authorization)
        films = detail.get('films') or []
        matched_name = detail.get('full_name', raw_name)
        self._remember(session, {'person_id': detail.get('uuid', person.get('uuid')), 'person_name': matched_name})
        answer = f'У {matched_name} — {len(films)} фильм(ов) в каталоге.'
        return self._response(
            query=query,
            session_id=session_id,
            intent='person_movie_count',
            answer_text=answer,
            confidence=0.9,
            used_services=['catalog'],
            metadata={'person_id': detail.get('uuid', person.get('uuid')), 'matched_name': matched_name, 'search_query': used_query, 'public_response_cache_key': cache_key},
            context=session,
            result={'type': 'person', 'name': matched_name, 'count': len(films), 'films': films},
            alternatives=alternatives,
        )

    async def _handle_person_filmography(
        self,
        query: str,
        authorization: str | None,
        session_id: str,
        session: dict[str, Any],
        person_name: str | None = None,
        search_queries: list[str] | None = None,
    ) -> AssistantResponse:
        raw_name = person_name or self._extract_person_name_with_context(query, session)
        if not raw_name:
            return self._response(
                query=query,
                session_id=session_id,
                intent='person_filmography',
                answer_text='Не удалось понять имя человека. Лучше написать его в кавычках.',
                confidence=0.2,
                used_services=[],
                metadata={},
                context=session,
            )
        person, alternatives, used_query = await self._resolve_person(raw_name, search_queries or [], authorization)
        if not person:
            return self._response(
                query=query,
                session_id=session_id,
                intent='person_filmography',
                answer_text=f'Не нашёл человека по запросу: {raw_name}.',
                confidence=0.2,
                used_services=['catalog'],
                metadata={'person_query': raw_name, 'search_queries': self._candidate_queries(raw_name, search_queries or [])},
                context=session,
                alternatives=alternatives,
            )
        cache_key = self._public_response_cache_key('person_filmography', entity_type='person', entity_id=str(person['uuid']))
        if not self._has_bearer(authorization):
            cached = await self._load_cached_public_response(cache_key, query, session_id, session)
            if cached is not None:
                return cached

        detail = await self._catalog_person_details(person['uuid'], authorization)
        films = detail.get('films') or []
        matched_name = detail.get('full_name', raw_name)
        self._remember(session, {'person_id': detail.get('uuid', person.get('uuid')), 'person_name': matched_name})
        if not films:
            answer = f'У меня нет фильмографии для {matched_name}.'
        else:
            film_details = await self._load_film_details([item.get('uuid') for item in films if item.get('uuid')], authorization)
            details_by_id = {item.get('uuid'): item for item in film_details if item.get('uuid')}
            titles = ', '.join(
                self._display_title(details_by_id.get(item.get('uuid')) or item)
                for item in films[:5]
                if self._display_title(details_by_id.get(item.get('uuid')) or item)
            )
            answer = f'У {matched_name} есть такие фильмы: {titles}.'
        return self._response(
            query=query,
            session_id=session_id,
            intent='person_filmography',
            answer_text=answer,
            confidence=0.88,
            used_services=['catalog'],
            metadata={'person_id': detail.get('uuid', person.get('uuid')), 'matched_name': matched_name, 'search_query': used_query, 'public_response_cache_key': cache_key},
            context=session,
            result={'type': 'person', 'name': matched_name, 'films': films},
            alternatives=alternatives,
        )

    async def _handle_bookmarks(self, query: str, authorization: str, session_id: str, session: dict[str, Any]) -> AssistantResponse:
        me = await self._me_or_none(authorization)
        if me is None:
            return self._auth_required_response(query, session_id, session, 'bookmarks')
        bookmarks = await self.ugc_client.bookmarks_by_user(str(me['id']), authorization)
        if not bookmarks:
            return self._response(
                query=query,
                session_id=session_id,
                intent='bookmarks',
                answer_text='У вас пока нет закладок.',
                confidence=0.95,
                used_services=['auth', 'ugc'],
                metadata={'bookmark_count': 0},
                context=session,
                result={'type': 'bookmarks', 'items': []},
            )
        details = await self._load_film_details([item['film_id'] for item in bookmarks], authorization)
        titles = ', '.join(self._display_title(detail) for detail in details[:5] if self._display_title(detail))
        answer = f'У вас в закладках {len(bookmarks)} фильм(ов): {titles}.'
        return self._response(
            query=query,
            session_id=session_id,
            intent='bookmarks',
            answer_text=answer,
            confidence=0.95,
            used_services=['auth', 'ugc', 'catalog'],
            metadata={'bookmark_count': len(bookmarks)},
            context=session,
            result={'type': 'bookmarks', 'items': details},
        )

    def _extract_explicit_genre_hint(self, query: str) -> str:
        cleaned = normalize_for_match(query)
        synonym_map = {
            'спорт': 'спорт',
            'спортив': 'спорт',
            'драма': 'драма',
            'драм': 'драма',
            'комедия': 'комедия',
            'комед': 'комедия',
            'романтика': 'романтика',
            'романт': 'романтика',
            'фантастика': 'фантастика',
            'фантаст': 'фантастика',
            'детектив': 'детектив',
        }
        for source, target in synonym_map.items():
            if source in cleaned:
                return target
        patterns = [
            r'в\s+жанре\s+([а-яё\- ]+)',
            r'жанра\s+([а-яё\- ]+)',
            r'жанр\s+([а-яё\- ]+)',
            r'из\s+([а-яё\- ]+)',
            r'([а-яё\- ]+)\s+фильмы',
        ]
        for pattern in patterns:
            match = re.search(pattern, cleaned, flags=re.IGNORECASE)
            if match:
                return match.group(1).strip()
        return ''

    async def _resolve_explicit_genre(self, query: str, authorization: str | None) -> dict[str, Any] | None:
        hint = self._extract_explicit_genre_hint(query)
        if not hint:
            return None
        genres = await self._catalog_search_genres(hint, authorization)
        if not genres:
            return None
        best = pick_best_candidate(hint, genres, lambda item: ' '.join([item.get('name', ''), ' '.join(item.get('aliases') or [])])) or genres[0]
        return best

    def _pick_single_recommendation(self, session: dict[str, Any], items: list[dict[str, Any]], key: str) -> dict[str, Any]:
        history_key = f'{key}_history'
        seen = [str(item) for item in session.get(history_key, []) if str(item)]
        unseen = [item for item in items if str(item.get('uuid')) not in seen]
        pool = unseen or items
        if not pool:
            return {}
        choice = random.choice(pool)
        chosen_id = str(choice.get('uuid') or '')
        if unseen:
            seen.append(chosen_id)
        else:
            seen = [chosen_id]
        session[history_key] = seen[-20:]
        return choice

    async def _handle_public_recommend_by_genre(
        self,
        query: str,
        authorization: str | None,
        session_id: str,
        session: dict[str, Any],
        genre_info: dict[str, Any],
    ) -> AssistantResponse:
        genre_id = str(genre_info.get('id') or genre_info.get('uuid') or '')
        genre_label = self._genre_display_name(genre_info, genre_id or 'этот жанр')
        if not genre_id:
            return self._response(
                query=query,
                session_id=session_id,
                intent='recommend_general',
                answer_text='Не удалось определить жанр. Попробуйте назвать его чуть точнее.',
                confidence=0.45,
                used_services=['catalog'],
                metadata={},
                context=session,
                result={'type': 'recommendations', 'items': []},
            )
        candidates = await self._catalog_films_by_genre(genre_id, authorization)
        if not candidates:
            return self._response(
                query=query,
                session_id=session_id,
                intent='recommend_general',
                answer_text=f'Пока не нашёл фильмов в жанре {genre_label}.',
                confidence=0.65,
                used_services=['catalog'],
                metadata={'genre': genre_label},
                context=session,
                result={'type': 'recommendations', 'genre': genre_label, 'items': []},
            )
        ranked = sorted(candidates, key=lambda item: item.get('imdb_rating') or 0, reverse=True)[:10]
        choice = self._pick_single_recommendation(session, ranked, f'genre:{genre_id}')
        display_title = self._display_title(choice)
        self._remember(session, {'film_id': choice.get('uuid'), 'film_title': display_title})
        return self._response(
            query=query,
            session_id=session_id,
            intent='recommend_general',
            answer_text=f'Из жанра {genre_label} попробуйте фильм «{display_title}». Рейтинг IMDb — {choice.get("imdb_rating", "—")}. Нажмите «Ещё», если нужен другой вариант.',
            confidence=0.87,
            used_services=['catalog'],
            metadata={'genre': genre_label, 'can_repeat': True},
            context=session,
            result={'type': 'recommendations', 'genre': genre_label, 'item': choice, 'items': [choice], 'can_repeat': True},
        )

    async def _handle_recommend_by_genre(self, query: str, authorization: str, session_id: str, session: dict[str, Any]) -> AssistantResponse:
        me = await self._me_or_none(authorization)
        if me is None:
            return self._auth_required_response(query, session_id, session, 'recommend_by_genre')
        bookmarks = await self.ugc_client.bookmarks_by_user(str(me['id']), authorization)
        likes = await self.ugc_client.likes_by_user(str(me['id']), authorization)
        positive_likes = [item for item in likes if int(item.get('value', 0)) >= 7]
        interacted_ids = list({item['film_id'] for item in [*bookmarks, *positive_likes]})
        if not interacted_ids:
            return self._response(
                query=query,
                session_id=session_id,
                intent='recommend_by_genre',
                answer_text='Пока не на что опереться. Добавьте хотя бы один фильм в закладки или поставьте высокую оценку.',
                confidence=0.8,
                used_services=['auth', 'ugc'],
                metadata={'interactions': 0},
                context=session,
                result={'type': 'recommendations', 'items': []},
            )

        details = await self._load_film_details(interacted_ids, authorization)
        genre_ids = [genre_id for detail in details for genre_id in (detail.get('genre') or [])]
        if not genre_ids:
            return self._response(
                query=query,
                session_id=session_id,
                intent='recommend_by_genre',
                answer_text='Я не смог определить ваши любимые жанры по текущим действиям.',
                confidence=0.6,
                used_services=['auth', 'ugc', 'catalog'],
                metadata={},
                context=session,
                result={'type': 'recommendations', 'items': []},
            )

        favorite_genre_id, _ = Counter(genre_ids).most_common(1)[0]
        genre_info = await self._catalog_genre_details(favorite_genre_id, authorization)
        genre_name = self._genre_display_name(genre_info, favorite_genre_id)
        candidates = await self._catalog_films_by_genre(favorite_genre_id, authorization)
        recommended = [item for item in candidates if item.get('uuid') not in set(interacted_ids)]
        recommended = recommended[: settings.RECOMMENDATION_LIMIT]
        if not recommended:
            return self._response(
                query=query,
                session_id=session_id,
                intent='recommend_by_genre',
                answer_text=f'Ваш любимый жанр — {genre_name}, но новых рекомендаций по нему у меня пока нет.',
                confidence=0.78,
                used_services=['auth', 'ugc', 'catalog'],
                metadata={'favorite_genre': genre_name},
                context=session,
                result={'type': 'recommendations', 'genre': genre_name, 'items': []},
            )
        items = ', '.join(f"{self._display_title(item)} ({item.get('imdb_rating', 'n/a')})" for item in recommended)
        answer = f'Похоже, вам нравится жанр {genre_name}. Могу предложить: {items}.'
        return self._response(
            query=query,
            session_id=session_id,
            intent='recommend_by_genre',
            answer_text=answer,
            confidence=0.9,
            used_services=['auth', 'ugc', 'catalog'],
            metadata={'favorite_genre': genre_name, 'recommendation_count': len(recommended)},
            context=session,
            result={'type': 'recommendations', 'genre': genre_name, 'items': recommended},
        )

    async def _handle_recommend_general(self, query: str, authorization: str | None, session_id: str, session: dict[str, Any]) -> AssistantResponse:
        explicit_genre = await self._resolve_explicit_genre(query, authorization)
        if explicit_genre is not None:
            return await self._handle_public_recommend_by_genre(query, authorization, session_id, session, explicit_genre)

        top_films = await self._catalog_list_top_films(authorization, limit=max(settings.RECOMMENDATION_LIMIT, 10))
        if not top_films:
            return self._response(
                query=query,
                session_id=session_id,
                intent='recommend_general',
                answer_text='Пока не могу предложить фильм: каталог пуст.',
                confidence=0.6,
                used_services=['catalog'],
                metadata={},
                context=session,
                result={'type': 'recommendations', 'items': []},
            )
        top_candidates = sorted(top_films, key=lambda item: item.get('imdb_rating') or 0, reverse=True)[:10]
        choice = self._pick_single_recommendation(session, top_candidates, 'general_recommendations')
        display_title = self._display_title(choice)
        self._remember(session, {'film_id': choice.get('uuid'), 'film_title': display_title})
        return self._response(
            query=query,
            session_id=session_id,
            intent='recommend_general',
            answer_text=f'Попробуйте фильм «{display_title}». Рейтинг IMDb — {choice.get("imdb_rating", "—")}. Нажмите «Ещё», если нужен другой вариант.',
            confidence=0.88,
            used_services=['catalog'],
            metadata={'can_repeat': True},
            context=session,
            result={'type': 'recommendations', 'item': choice, 'items': [choice], 'can_repeat': True},
        )

    async def _handle_recommend_by_person(
        self,
        query: str,
        authorization: str | None,
        session_id: str,
        session: dict[str, Any],
        person_name: str | None = None,
        search_queries: list[str] | None = None,
    ) -> AssistantResponse:
        raw_name = person_name or self._extract_person_name_with_context(query, session)
        if not raw_name:
            return self._response(
                query=query,
                session_id=session_id,
                intent='recommend_by_person',
                answer_text='Не удалось понять, про какого человека идёт речь. Лучше написать имя в кавычках.',
                confidence=0.2,
                used_services=[],
                metadata={},
                context=session,
            )
        person, alternatives, used_query = await self._resolve_person(raw_name, search_queries or [], authorization)
        if not person:
            return self._response(
                query=query,
                session_id=session_id,
                intent='recommend_by_person',
                answer_text=f'Не нашёл человека по запросу: {raw_name}.',
                confidence=0.2,
                used_services=['catalog'],
                metadata={'person_query': raw_name, 'search_queries': self._candidate_queries(raw_name, search_queries or [])},
                context=session,
                alternatives=alternatives,
            )
        detail = await self._catalog_person_details(person['uuid'], authorization)
        films = detail.get('films') or []
        matched_name = detail.get('full_name', raw_name)
        self._remember(session, {'person_id': detail.get('uuid', person.get('uuid')), 'person_name': matched_name})
        if not films:
            answer = f'У меня пока нет фильмов, чтобы рекомендовать по {matched_name}.'
            items: list[dict[str, Any]] = []
        else:
            sorted_films = sorted(films, key=lambda item: item.get('imdb_rating') or 0, reverse=True)
            items = sorted_films[: settings.RECOMMENDATION_LIMIT]
            answer = f'Могу предложить фильмы с участием или от {matched_name}: ' + ', '.join(
                f"{self._display_title(item)} ({item.get('imdb_rating', 'n/a')})" for item in items
            ) + '.'
        return self._response(
            query=query,
            session_id=session_id,
            intent='recommend_by_person',
            answer_text=answer,
            confidence=0.86,
            used_services=['catalog'],
            metadata={'person_id': detail.get('uuid', person.get('uuid')), 'matched_name': matched_name, 'search_query': used_query},
            context=session,
            result={'type': 'recommendations', 'items': items, 'person_name': matched_name},
            alternatives=alternatives,
        )

    async def _resolve_person(
        self,
        person_name: str,
        search_queries: list[str],
        authorization: str | None,
    ) -> tuple[dict[str, Any] | None, list[dict[str, Any]], str | None]:
        collected: list[dict[str, Any]] = []
        used_query: str | None = None
        for candidate in self._candidate_queries(person_name, search_queries):
            people = await self._catalog_search_persons(candidate, authorization)
            if people:
                collected = people
                used_query = candidate
                break
        if not collected:
            token_candidates = [token for token in normalize_for_match(person_name).split() if len(token) >= 4]
            for token in token_candidates:
                people = await self._catalog_search_persons(token, authorization)
                if people:
                    collected = people
                    used_query = token
                    break
        if not collected:
            return None, [], used_query
        best = pick_best_candidate(person_name, collected, lambda item: item.get('full_name', '')) or collected[0]
        return best, self._person_alternatives(collected), used_query

    async def _resolve_film(
        self,
        film_title: str,
        search_queries: list[str],
        authorization: str | None,
    ) -> tuple[dict[str, Any] | None, list[dict[str, Any]], str | None]:
        collected: list[dict[str, Any]] = []
        used_query: str | None = None
        for candidate in self._candidate_queries(film_title, search_queries):
            films = await self._catalog_search_films(candidate, authorization)
            if films:
                collected = films
                used_query = candidate
                break
        if not collected:
            fallback = await self._catalog_list_top_films(authorization, limit=50)
            if fallback:
                collected = fallback
                used_query = '__top_films_fallback__'
        if not collected:
            return None, [], used_query
        best = pick_best_candidate(
            film_title,
            collected,
            lambda item: ' '.join(
                [
                    item.get('title', ''),
                    item.get('original_title', ''),
                    ' '.join(item.get('title_aliases') or []),
                ]
            ),
        ) or collected[0]
        return best, self._film_alternatives(collected), used_query

    @staticmethod
    def _candidate_queries(primary: str, extras: list[str]) -> list[str]:
        seen: list[str] = []
        for item in [primary, *extras]:
            value = item.strip()
            if value and value not in seen:
                seen.append(value)
        return seen

    async def _load_film_details(self, film_ids: Iterable[str], authorization: str | None) -> list[dict[str, Any]]:
        details: list[dict[str, Any]] = []
        for film_id in film_ids:
            try:
                details.append(await self._catalog_film_details(film_id, authorization))
            except httpx.HTTPStatusError:
                continue
        return details

    async def _resolve_genre_names(self, genre_ids: Iterable[str], authorization: str | None) -> list[str]:
        names: list[str] = []
        for genre_id in genre_ids:
            try:
                genre = await self._catalog_genre_details(genre_id, authorization)
                if genre.get('name'):
                    names.append(genre['name'])
            except httpx.HTTPStatusError:
                names.append(genre_id)
        return names

    @staticmethod
    def _normalize(value: str) -> str:
        return ' ' + normalize_for_match(value) + ' '

    def _extract_film_title_with_context(self, query: str, session: dict[str, Any]) -> str:
        quoted = self._extract_quoted(query)
        if quoted:
            return quoted
        if self._looks_like_film_followup(query) and session.get('film_title'):
            return str(session['film_title'])
        tail = self._extract_tail(
            query,
            [
                r'(?:оценк[аи]?|рейтинг)[^\w]*(?:у|фильма)?\s+(.+)$',
                r'(?:кто\s+режисс[её]р\s+фильма|режисс[её]р\s+фильма|автор\s+фильма|кто\s+снял(?:\s+фильм)?|кто\s+снимал(?:\s+фильм)?|кто\s+поставил(?:\s+фильм)?)\s+(.+)$',
                r'(?:сколько\s+длится\s+фильм|длительность\s+фильма)\s+(.+)$',
                r'(?:жанр(?:ы)?\s+фильма|какие\s+жанры\s+у\s+фильма)\s+(.+)$',
                r'(?:расскажи\s+про\s+фильм|что\s+за\s+фильм|(?:кратк\w*|коротк\w*)\s+сводк\w*\s+по\s+фильму|описан\w*\s+фильма|сюжет\w*\s+фильма|кратко\s+о\s+фильме|дай\s+(?:(?:кратк\w*|коротк\w*)\s+)?сводк\w*\s+по\s+фильму)\s+(.+)$',
            ],
        )
        if tail:
            return tail
        return ''

    def _extract_person_name_with_context(self, query: str, session: dict[str, Any]) -> str:
        quoted = self._extract_quoted(query)
        if quoted:
            return quoted
        if self._looks_like_person_followup(query) and session.get('person_name'):
            return str(session['person_name'])
        tail = self._extract_tail(
            query,
            [
                r'(?:сколько\s+фильмов\s+у|какие\s+фильмы\s+у|посоветуй\s+фильмы\s+с)\s+(.+)$',
            ],
        )
        if tail:
            return tail
        return ''

    @staticmethod
    def _extract_quoted(query: str) -> str:
        for pattern in [r'«([^»]+)»', r'"([^"]+)"']:
            match = re.search(pattern, query)
            if match:
                return match.group(1).strip()
        return ''

    @staticmethod
    def _extract_tail(query: str, patterns: list[str]) -> str:
        cleaned = query.strip().rstrip('?.! ')
        for pattern in patterns:
            match = re.search(pattern, cleaned, flags=re.IGNORECASE)
            if match:
                value = match.group(1).strip().strip('?.! ')
                return value
        return ''

    @staticmethod
    def _looks_like_film_followup(query: str) -> bool:
        text = AssistantService._normalize(query)
        return any(
            token in text for token in [' он', ' него', ' этот фильм', ' этого фильма', ' его ', ' у него']
        ) or text.startswith(' а сколько') or text.startswith(' а какие')

    @staticmethod
    def _looks_like_person_followup(query: str) -> bool:
        text = AssistantService._normalize(query)
        return any(
            token in text for token in ['этот автор', 'этот режиссер', 'этот режиссёр', 'у неё', 'у нее']
        ) or text.startswith(' а сколько')

    def _remember(self, session: dict[str, Any], context: dict[str, Any]) -> None:
        session.update({key: value for key, value in context.items() if value is not None})

    @staticmethod
    def _film_alternatives(films: list[dict[str, Any]]) -> list[dict[str, Any]]:
        return [
            {
                'id': item.get('uuid'),
                'title': item.get('title'),
                'rating': item.get('imdb_rating'),
            }
            for item in films[:3]
        ]

    @staticmethod
    def _person_alternatives(people: list[dict[str, Any]]) -> list[dict[str, Any]]:
        return [
            {
                'id': item.get('uuid'),
                'name': item.get('full_name'),
            }
            for item in people[:3]
        ]

    @staticmethod
    def _help_text() -> str:
        capabilities = get_capabilities().get('intents', [])
        visible = [item for item in capabilities if item['name'] != 'help']
        pieces = ', '.join(item['description'].lower() for item in visible[:6])
        return f'Я умею: {pieces}. Ещё могу показать ваши закладки и дать рекомендации после входа.'

    @staticmethod
    def _response(
        *,
        query: str,
        session_id: str,
        intent: str,
        answer_text: str,
        confidence: float,
        used_services: list[str],
        metadata: dict[str, Any],
        context: dict[str, Any],
        result: Any = None,
        alternatives: list[dict[str, Any]] | None = None,
        requires_auth: bool = False,
        speak_text: str | None = None,
    ) -> AssistantResponse:
        normalized_speak = speak_text or answer_text
        return AssistantResponse(
            query=query,
            session_id=session_id,
            intent=intent,
            answer=answer_text,
            answer_text=answer_text,
            speak_text=normalized_speak,
            requires_auth=requires_auth,
            confidence=confidence,
            used_services=used_services,
            metadata=metadata,
            context=dict(context),
            result=result,
            alternatives=alternatives or [],
        )


def build_assistant_service(client: httpx.AsyncClient, session_redis: Any) -> AssistantService:
    llm_client = LocalLlmClient(client)
    session_store = RedisSessionStore(
        redis=session_redis,
        ttl_seconds=settings.ASSISTANT_SESSION_TTL_SECONDS,
        key_prefix=settings.ASSISTANT_SESSION_KEY_PREFIX,
    )
    parse_cache = RedisParseCacheStore(
        redis=session_redis,
        ttl_seconds=settings.ASSISTANT_PARSE_CACHE_TTL_SECONDS,
        key_prefix=settings.ASSISTANT_PARSE_CACHE_KEY_PREFIX,
    )
    public_response_cache = RedisPublicResponseCacheStore(
        redis=session_redis,
        ttl_seconds=settings.ASSISTANT_PUBLIC_RESPONSE_CACHE_TTL_SECONDS,
        key_prefix=settings.ASSISTANT_PUBLIC_RESPONSE_CACHE_KEY_PREFIX,
    )
    feedback_store = RedisFeedbackStore(
        redis=session_redis,
        key_prefix=settings.ASSISTANT_FEEDBACK_KEY_PREFIX,
        max_events=settings.ASSISTANT_FEEDBACK_MAX_EVENTS,
    )
    llm_circuit_store = RedisLlmCircuitStore(
        redis=session_redis,
        key_prefix=settings.ASSISTANT_FEEDBACK_KEY_PREFIX,
        failure_threshold=settings.ASSISTANT_LLM_FAILURE_THRESHOLD,
        cooldown_seconds=settings.ASSISTANT_LLM_COOLDOWN_SECONDS,
    )
    return AssistantService(
        auth_client=AuthClient(client),
        catalog_client=CatalogClient(client),
        ugc_client=UgcClient(client),
        session_store=session_store,
        llm_client=llm_client,
        parse_cache=parse_cache,
        public_response_cache=public_response_cache,
        feedback_store=feedback_store,
        llm_circuit_store=llm_circuit_store,
    )
